from setuptools import setup

setup(
    name="opal_fetcher_mongo",
    version="0.0.1",
)